package com.example.Customer.model;

public class Customermodel {
public int id ;
public String name;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getBranchLocation() {
	return BranchLocation;
}
public void setBranchLocation(String branchLocation) {
	BranchLocation = branchLocation;
}


public String BranchLocation;
public Customermodel(int id, String name, String branchLocation) {
	super();
	this.id = id;
	this.name = name;
	BranchLocation = branchLocation;
}

}


