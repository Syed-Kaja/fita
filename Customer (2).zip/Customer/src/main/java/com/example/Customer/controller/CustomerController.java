package com.example.Customer.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Customer.model.Customermodel;

@RestController
public class CustomerController {

	/*@GetMapping("car")
	Car getCar() {
		Car car = new Car();
		car.color="blue";
		return car;
		*/
		
		
	/*	@GetMapping("customermodel")
		Customermodel getCustomermodel() {
			Customermodel customer = new Customermodel();
			customer.id=786;
			customer.name="Syed";
			customer.BranchLocation="Porur";
			return customer;
		
	}
}*/
	
	/* @GetMapping("customermodel")
	Customermodel getCustomermodel() {
		Customermodel customer = new Customermodel(123,"porur","chennai");
	
		return customer;
	
} */
	
	
	
}



