package com.example.Customer.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.Customer.model.Customermodel;

import jakarta.websocket.server.PathParam;

import com.example.Customer.CustomerRepository;
import com.example.Customer.model.CustomerEntity;

@Controller
public class ViewController {

	@Autowired
	//using this anotation is used for getting object form BEAN fectory
	CustomerRepository customerrepository; //customerrepository this object using from beanfactory
	
	@GetMapping("Contact")
	String getContactPage() {
		return "Contact";
	}

	@GetMapping("home")
	String getHome(Model model) {
		model.addAttribute("address", "porur");

		// obj creation
		Customermodel customer = new Customermodel(123, "fita", "porur");

		model.addAttribute("customerObj", customer);

		List<Customermodel> list = new ArrayList<Customermodel>();
		list.add(new Customermodel(123, "porur", "chennai"));
		list.add(new Customermodel(123, "porur", "chennai"));
		list.add(new Customermodel(123, "porur", "chennai"));
		model.addAttribute("customerlist", list);

		return "home";
	}

	@GetMapping("login")
	String getloginpage() {
		return "login";
	}
	
	@GetMapping("login/{message}")
	String getloginpage(@PathVariable("message") String message, Model model) {
		System.out.println(message);
		if(message.equals("failure")) {
			model.addAttribute("loginmessage", " failed");
		}else if( message.equals("Success")){
			model.addAttribute("loginmessage","Success");	
		}
		
		return "login";
	}
	
	@PostMapping("loginvalidate")
	String loginvalidate(@RequestParam("email") String email,
			@RequestParam("password") String password, Model model) {
		
		System.out.println(email);
		System.out.println(password);
		if(email.equals("kajamass007@gmail.com") && password.equals("1234")) {
			model.addAttribute("loginmessage", "login Successful"); 
		}else {
			model.addAttribute("loginmessage", "try again");
		}
		return "login";
	}
	
	@GetMapping("CustomerForm")// customerform vanthu url la kodukura name
	String getCustomerForm(Model model) {
		model.addAttribute("address", "");
		Customermodel customer = new Customermodel(123, "fita", "porur");
		List list = customerrepository.findAll();

		model.addAttribute("customerByid",new CustomerEntity());
		model.addAttribute("customerlist", list);
		
		return "CustomerForm"; // Customerform vanthu html page name
	}
	
	@PostMapping("customer")
	String Customer(@RequestParam("name") String name,
			@RequestParam("branchlocation") String branchlocation, 
			@RequestParam(name="id", required=false)int id,Model model) {
		CustomerEntity customer = new CustomerEntity();
		customer.setBranchLocation(branchlocation);
		customer.setName(name);
		if(id!=0)
			customer.setId(id);
	
		customerrepository.save(customer);
		//List list = customerrepository.findAll();
		//model.addAttribute("customerlist", list); 
		
		return "redirect:/CustomerForm";
	}
	
	@GetMapping("deleteCustomerform/{customerid}")
	String getdeleteform(@PathVariable("customerid")  Integer id ){
		
		CustomerEntity CustomerEntity = new CustomerEntity();
		CustomerEntity.setId(id);
		customerrepository.delete(CustomerEntity);
		
		return "redirect:/CustomerForm";
	}
	
	@GetMapping("CustomerFormm/{customerid}")// customerform vanthu url la kodukura name
	String getcustomerformid(Model model,@PathVariable("customerid")  Integer id ){
		Optional<CustomerEntity> customerentity= customerrepository.findById(id);
		
		model.addAttribute("customerByid", customerentity.get());
		List<CustomerEntity>  list = customerrepository.findAll();
		model.addAttribute("customerlist", list);
		
		return "CustomerForm";
}
}