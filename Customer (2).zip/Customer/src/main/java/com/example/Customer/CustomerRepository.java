package com.example.Customer;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Customer.model.CustomerEntity;

public interface CustomerRepository extends JpaRepository<CustomerEntity, Integer>{

}
